import { useState } from 'react';

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  return (
    <header className="bg-white shadow-md fixed w-full top-0 z-50">
      <nav className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="text-2xl font-bold text-blue-900">ExFreight</div>
        
        <div className="hidden md:flex space-x-8">
          <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-orange-500">Home</button>
          <button onClick={() => scrollToSection('services')} className="text-gray-700 hover:text-orange-500">Services</button>
          <button onClick={() => scrollToSection('industries')} className="text-gray-700 hover:text-orange-500">Industries</button>
          <button onClick={() => scrollToSection('about')} className="text-gray-700 hover:text-orange-500">About</button>
          <button onClick={() => scrollToSection('contact')} className="text-gray-700 hover:text-orange-500">Contact</button>
        </div>

        <button onClick={() => scrollToSection('quote')} className="hidden md:block bg-orange-500 text-white px-6 py-2 rounded-lg hover:bg-orange-600">
          Get Quote
        </button>

        <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </nav>

      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t">
          <div className="px-4 py-2 space-y-2">
            <button onClick={() => scrollToSection('home')} className="block w-full text-left py-2">Home</button>
            <button onClick={() => scrollToSection('services')} className="block w-full text-left py-2">Services</button>
            <button onClick={() => scrollToSection('industries')} className="block w-full text-left py-2">Industries</button>
            <button onClick={() => scrollToSection('about')} className="block w-full text-left py-2">About</button>
            <button onClick={() => scrollToSection('contact')} className="block w-full text-left py-2">Contact</button>
            <button onClick={() => scrollToSection('quote')} className="bg-orange-500 text-white px-6 py-2 rounded-lg w-full">Get Quote</button>
          </div>
        </div>
      )}
    </header>
  );
}
